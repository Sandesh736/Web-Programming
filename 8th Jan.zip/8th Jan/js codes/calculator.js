function calculate(op)
{
// documnet refers to html page
    
    a = parseInt(document.getElementById("num1").value)
    b = parseInt(document.getElementById("num2").value)


    switch(op)
    {
        case '+':
             c = a+b
             break
        case '-':
            c = a-b
            break
        case '*':
            c = a*b
            break
    }
    // document.getElementById("num3").value = c
    document.write(c)
}