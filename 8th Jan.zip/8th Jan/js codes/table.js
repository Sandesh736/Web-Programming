// function findTable()
// {
//     no = parseInt(document.getElementById("num").value)

//     str = ""
//     for(i=1;i<=10;i++)
//     {
//         ans = i * no 
//         str = str + ans + "<br> "
//     }

//     document.getElementById("result").innerHTML = str


// }


function findTable()
{
    no = parseInt(document.getElementById("num").value)

    str = "<table border=1 style=border-collapse:collapse>"
    for(i=1;i<=10;i++)
    {
        str += "<tr>"
        ans = i * no 
        str +="<Td>" +no +" * "+i +"</td>"
        str +="<td>  =  </td>"
        str += "<td>" + ans +"</td>"
        str +="</tr>"

    }
    str += "</table>"
    document.getElementById("result").innerHTML = str


}