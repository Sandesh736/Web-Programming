
function validate()
{
    var1 = document.getElementById("uname").value
    var2 = document.getElementById("pass").value

    if(var1.length ==0 )
    {
    //   alert("Plz enter username")   
    document.getElementById("uerror").innerText="please enter username"
    }
    else if(var2.length == 0)
    {
        // alert("plz enter password")
        document.getElementById("perror").innerText="please enter password"
    }
    else{
        form1.submit()
    }
}


function cleartext()
{
    
    document.getElementById("uerror").innerText=""
    document.getElementById("perror").innerText=""
}

