let s1 = "FirstBit solutions"

let s2 = new String("JavaScript")

s3 = s1.concat(s2)
document.write(s1.length+"<br>")
document.write("Char At:"+s1.charAt(3)+"<br>")
document.write("concat:"+s1.concat(s2)+"<br>")
document.write("indexof:"+s1.indexOf('B')+"<br>")
document.write("Lastindexof:"+s1.lastIndexOf('i')+"<br>")
document.write("touppercase:"+s1.toUpperCase()+"<br>")
document.write("Substring: "+s1.substring(5,8)+"<br>")

// Separate username from given mailid
str =  "sonal.firstbitsolutions@gmail.com"

ind = str.indexOf('@')
username = str.substring(0,ind)
document.write(username+"<br>")

// array of spitted strings
sarr =str.split('@')
document.write("using split():"+sarr[0]+"<BR>")
document.write("using split():"+sarr[1])

str1 = "Monday-Tuesday-Wednesday-Thursday-Friday-Saturday-Sunday"
days = str1.split('-')
document.write(days+"<br>")
str.

new_str = str.replace("sonal", "Gauri")
str = str.replace("sonal", "Gauri")
document.write(new_str)