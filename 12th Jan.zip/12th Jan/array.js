// Array

arr = [10,20,30,40]



arr[4]= 50
// document.write(arr[2])
for(i=0;i<arr.length;i++)
{
    document.write(arr[i]+"<br>")
}

arr.pop()
document.write("Size after pop:"+arr.length+"<br>")

document.write(arr.indexOf(400)+"<br>")

new_arr =[]
for(i=0;i<arr.length; i++)
{
   new_arr[i] = arr[i]/2
}

// document.write(new_arr)

arr = [10,20,30,40]
new_arr = []
// for(i=0;i<arr.length;i++)
// {
//     new_arr[i] = divide(arr[i])
// }




// function divide(x)
// {
//     return x / 2
// }
divide = (x)=>
{
    return x/2
}

// map() will traverse thr array & perform the specified oeration on each element of array

// new_arr = arr.map(divide)

new_arr = arr.map((x)=>
                    {
                        return x/2
                    })



document.write("After map(): "+new_arr)