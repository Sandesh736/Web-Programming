evenodd = (a) =>
{
    if(a%2 ==0)
    {
        document.write("even <bR>")
    }
    else
     document.write("odd <br>")
}

function fun1(evenodd,arr)
{
    for (i=0;i<arr.length;i++)
        evenodd(arr[i])

}

arr=[12,45,67,89,22,44]

fun1(evenodd,arr)

