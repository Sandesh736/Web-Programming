// d = Date()
// January : 0

d = new Date(2023,0,21)
document.write(d+"<BR>")
// document.write(d.getDay()+" "+d.getMonth()+" "+d.getFullYear())
document.write(d.getDate())