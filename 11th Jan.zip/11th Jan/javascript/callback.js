
function display()
{
    alert("Welcome")
}
// callback functions are used for function chaining 
//1 sec = 1000 ms
// call display method after 5 sec
// a function is parameter to another function

// setTimeout(display,5000) //5000 ms

setTimeout(()=>
    {
        alert("welcome")
    } ,5000)

// setInterval(display,5000)