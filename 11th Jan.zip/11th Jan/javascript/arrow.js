// sq = function (x)
// {
//     return x* x

// }
// arrow function
sq = (x) =>
{
    var1 = x * x
    return var1
}
// document.write(sq(10))

function find(a)
{
    ans = sq(a)
    if(ans>50)
       document.write(ans)
}

// find(5)