function click1()
{
    num = 1
    do
    {
        document.write(num+"<br>")
        num ++
        // boolean

        v = confirm("Do you want to continue??")
        
    }while(v == true)
}
