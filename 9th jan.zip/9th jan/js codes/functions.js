// assigning a  function as value to variable

// var1 = function(a, b)
// {
//     c = a +b

//     document.write(c+"<br>")
// }


// add(70,10)
// Arrow function
var1 = (a,b) =>
{
    c = a+b
    document.write(c)
}
var1(10,20)
// document.write(typeof(var1))