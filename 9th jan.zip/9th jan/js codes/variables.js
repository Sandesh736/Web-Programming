
//Data type
// number (int ,float)
// string
// boolean

// Declaration types

// var, let, const

// global declaration
var a = 10

function display()
{
    // block scoped variable declaration
    var a = 10
    const b = 20
    // b = b- 10
    document.write(a+"<br>")

    a = 20
}


display()
document.write(a)