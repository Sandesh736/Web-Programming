function factorial()
{
    no = parseInt(document.getElementById("num1").value)

    f = 1
    while(no >0)
    {
        f = f* no
        no--
    }
    document.getElementById("num2").value = f
}